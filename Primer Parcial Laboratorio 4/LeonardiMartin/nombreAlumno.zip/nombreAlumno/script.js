    
    
    const xhr = new XMLHttpRequest();

    xhr.open('GET', 'https://moviesdatabase.p.rapidapi.com/titles/x/upcoming');
    xhr.setRequestHeader('X-RapidAPI-Key', '67ce9a7bddmsheb5e568c085e441p16581cjsndd627b02a361');
    xhr.setRequestHeader('X-RapidAPI-Host', 'moviesdatabase.p.rapidapi.com');
      
    xhr.onload = function() {
      if (  ) {
        console.log('respuesta del servidor o API');
        resolve();
      }else{
        reject('error');
      }
    };
  
    xhr.send(data);

